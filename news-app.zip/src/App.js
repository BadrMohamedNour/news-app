import React, { Component } from "react";
import { Route, Switch } from "react-router-dom";
import Articles from "./Containers/Articles/Articles";
import Toolbar from "./Components/Toolbar/Toolbar";
import Favorites from "./Containers/Favorites/Favorites";
import Signup from "./Components/Form/Signup/Signup";
import Login from "./Components/Form/Login/Login";
class App extends Component {
  render() {
    return (
      <div>
        <Toolbar />
        <Switch>
          <Route path="/favorites" component={Favorites} />
          <Route path="/signup" component={Signup} />
          <Route path="/login" component={Login} />
          <Route path="/" exact component={Articles} />
        </Switch>
      </div>
    );
  }
}

export default App;
