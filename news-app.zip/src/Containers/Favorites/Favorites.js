import React, { useContext, useState } from "react";
import { AuthContext } from "../../Components/authContext/authContext";
import Spinner from "../../Components/UI/Spinner/Spinner";
import Article from "../../Components/Article/Article";
import classes from "./Favorites.css";
const favorites = (props) => {
  // connect Component to Context
  const authContext = useContext(AuthContext);
  // To re-render Component After any Update
  const [toggle, setToggle] = useState(false);
  // Remove Articles from Favorites
  const removeFavoriteHandler = (artT) => {
    let all = authContext.fav;
    let favArt = all.findIndex((fav) => fav.title === artT);
    all.splice(favArt, 1);
    authContext.setFav(all);
    setToggle(!toggle);
  };
  // To Show Spinner Until All Favorite Articles Loaded
  let favorite = <Spinner />;
  if (authContext.fav.length !== 0) {
    favorite = authContext.fav.map((fav) => (
      <Article
        favText="RFF"
        key={fav.title}
        title={fav.title}
        image={fav.urlToImage}
        author={fav.author}
        date={fav.publishedAt}
        content={fav.description}
        link={fav.url}
        favorite={() => removeFavoriteHandler(fav.title)}
      />
    ));
  } else {
    // if There Are No Favorite Articles
    favorite = <p className={classes.Fav}>There are no Favorite Articles</p>;
  }
  return <div>{favorite}</div>;
};
export default favorites;
