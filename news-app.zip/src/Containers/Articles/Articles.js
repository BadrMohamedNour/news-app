import React, { Component, Fragment } from "react";
import axios from "axios";
import Article from "../../Components/Article/Article";
import Spinner from "../../Components/UI/Spinner/Spinner";
import Modal from "../../Components/UI/Modal/Modal";
import classes from "./Articles.css";
import { AuthContext } from "../../Components/authContext/authContext";
class Articles extends Component {
  state = {
    sports: null,
    business: null,
    hasError: false,
    show: false,
    message: "",
  };
  // Connect Component To Context
  static contextType = AuthContext;
  // Get Atricles From Business & Sports fields
  componentDidMount() {
    axios
      .get(
        "https://newsapi.org/v2/top-headlines?" +
          "country=eg&category=sports" +
          "&apiKey=ff8ae2e12e3e4bc5bf9ff3538f15a5b7"
      )
      .then((respose) => {
        this.setState({ sports: respose.data.articles });
      })
      .catch((error) =>
        this.setState({ hasError: true, show: true, message: error.message })
      );
    axios
      .get(
        "https://newsapi.org/v2/top-headlines?" +
          "country=eg&category=business" +
          "&apiKey=ff8ae2e12e3e4bc5bf9ff3538f15a5b7"
      )
      .then((respose) => {
        this.setState({ business: respose.data.articles });
      })
      .catch((error) =>
        this.setState({ hasError: true, show: true, message: error.message })
      );
  }
  // To Add Article To Favorites
  addFavoriteHandler = (artT) => {
    const allArticles = [...this.state.sports, ...this.state.business];
    let favArt = allArticles.findIndex((fav) => fav.title === artT);
    this.context.setFav([...this.context.fav, allArticles[favArt]]);
  };
  // To Close Modal In Case  there is Error
  closeModalHandler = () => {
    this.setState({ show: false });
  };
  render() {
    let sports = null;
    let business = null;
    // To Show  Either Spinner  Or Error In Case  there is Error
    let articles = this.state.hasError ? (
      <Modal show={this.state.show} modalClosed={this.closeModalHandler}>
        <p>{this.state.message}</p>
      </Modal>
    ) : (
      <Spinner />
    );
    if (this.state.sports && this.state.business) {
      // To Loop Through Sports Articles And Return this Articles
      sports = this.state.sports.map((artKey) => (
        <Article
          favText="ATF"
          key={artKey.title}
          image={artKey.urlToImage}
          title={artKey.title}
          author={artKey.author}
          date={artKey.publishedAt}
          content={artKey.description}
          link={artKey.url}
          favorite={() => this.addFavoriteHandler(artKey.title)}
        />
      ));
      // To Loop Through Business Articles And Return this Articles
      business = this.state.business.map((artKey, i) => (
        <Article
          favText="ATF"
          key={artKey.title}
          image={artKey.urlToImage}
          title={artKey.title}
          author={artKey.author}
          date={artKey.publishedAt}
          content={artKey.description}
          link={artKey.url}
          favorite={() => this.addFavoriteHandler(artKey.title)}
        />
      ));
      // To Return Two Culomns Of Articles
      articles = (
        <Fragment>
          <div className={classes.Sports}>
            <h2>الرياضة</h2>
            {sports}
          </div>
          <div className={classes.Business}>
            <h2>الاعمال</h2>
            {business}
          </div>
        </Fragment>
      );
    }

    return <div className={classes.Articles}>{articles}</div>;
  }
}
export default Articles;
