import React, { useState } from "react";
export const AuthContext = React.createContext({});
const authProvider = (props) => {
  // To Logout Or Login
  const [auth, setAuth] = useState(false);
  // To Add Articles To Favorites
  const [fav, setFav] = useState([]);
  return (
    <AuthContext.Provider value={{ auth, setAuth, fav, setFav }}>
      {props.children}
    </AuthContext.Provider>
  );
};
export default authProvider;
