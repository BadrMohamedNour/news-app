import React from "react";
import classes from "./Backdrop.css";
// To Make Overlay On All Of The Page
const backdrop = (props) =>
  props.show ? (
    <div className={classes.Backdrop} onClick={props.clicked}></div>
  ) : null;
export default backdrop;
