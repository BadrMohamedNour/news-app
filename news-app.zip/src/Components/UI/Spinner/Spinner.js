import React from "react";
import classes from "./Spinner.css";
// To Show Spinner Until Page Loading
const spinner = () => <div className={classes.Loader}>Loading...</div>;

export default spinner;
