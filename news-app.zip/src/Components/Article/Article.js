import React from "react";
import classes from "./Article.css";
// Article Structure
const news = (props) => {
  return (
    <div className={classes.Article}>
      <span className={classes.Favorite} onClick={props.favorite}>
        {props.favText}
      </span>
      <div className={classes.image}>
        <img src={props.image} alt={props.title} />
      </div>
      <div className={classes.info}>
        <h4>{props.title}</h4>
        <h5>{props.author}</h5>
        <h6 className={classes.Date}>{props.date}</h6>
        <p>{props.content}</p>
        <a href={props.link}>المصدر</a>
      </div>
    </div>
  );
};

export default news;
