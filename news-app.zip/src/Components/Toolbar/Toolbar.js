import React, { useContext } from "react";
import { Link } from "react-router-dom";
import classes from "./Toolbar.css";
import { AuthContext } from "../authContext/authContext";
const toolbar = (props) => {
  // To Connect Component To Context
  const authContext = useContext(AuthContext);
  // To Logout
  const logout = () => {
    authContext.setAuth(false);
  };
  return (
    <div className={classes.Toolbar}>
      <nav>
        {authContext.auth ? (
          <a onClick={logout}>تسجيل الخروج</a>
        ) : (
          <Link to="signup" className={classes.Link}>
            انشاء حساب / تسجيل الدخول
          </Link>
        )}
        <Link to="/" className={classes.Link}>
          الرئيسية
        </Link>
        <Link to="favorites" className={classes.Link}>
          المفضلة
        </Link>
      </nav>
      <h1>News App</h1>
    </div>
  );
};

export default toolbar;
