import axios from "axios";
import React, { useState, useContext } from "react";
import { Link, Redirect } from "react-router-dom";
import classes from "../Form.css";
import { AuthContext } from "../../authContext/authContext";
const signup = () => {
  const authContext = useContext(AuthContext);
  const [state, setState] = useState({ email: "", password: "" });
  const [redir, setRedir] = useState(false);
  const submitHandler = (e) => {
    e.preventDefault();
    const data = {
      email: state.email,
      password: state.password,
    };
    // Check If Email And Password True
    axios
      .post(
        "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyAxZZQxHAlEkprGQxUgG1UoYkK1T2cKJB0",
        data
      )
      .then((response) => {
        console.log(response);
        authContext.setAuth(true);
        setRedir(true);
      });
  };
  const changeHandler = (e) => {
    setState({ ...state, [e.target.name]: e.target.value });
  };

  return (
    <div className={classes.Content}>
      {redir ? <Redirect to="/" /> : null}
      <form method="post" onSubmit={submitHandler} className={classes.Form}>
        <h1>News App</h1>
        <h3>Login</h3>
        <div>
          <label htmlFor="email">
            <input
              type="email"
              name="email"
              placeholder="Email"
              value={state.email}
              onChange={changeHandler}
            />
          </label>
        </div>
        <div>
          <label htmlFor="password">
            <input
              type="password"
              name="password"
              placeholder="Password"
              value={state.password}
              onChange={changeHandler}
            />
          </label>
        </div>
        <button type="submit">Login</button>
        <span className={classes.Login}>
          don't have an account? Signup <Link to="signup">here</Link>
        </span>
      </form>
    </div>
  );
};

export default signup;
