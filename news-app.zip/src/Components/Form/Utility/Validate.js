const validate = (values) => {
  let error = {};
  if (!values.username.trim()) {
    // Check If UserName Input Is Empty After Removing The Spaces
    error.username = "User Name is required";
  } else if (values.username.trim().length < 8) {
    // Check If UserName Input Is Less Than  8 Characters After Removing The Spaces
    error.username = "User Name must be more than 8 characters";
  }
  if (!values.email) {
    // Check If Email Input Is Empty After Removing The Spaces
    error.username = "Email is required";
  } else if (!/\S+@\S+\.\S+/.test(values.email)) {
    // Check If Email Apply This Pattern
    error.email = "Email address is invalid";
  }
  if (!values.birthday) {
    // Check If Date Input Is Empty
    error.date = "Date is required";
  }
  return error;
};
export default validate;
