function getRandomLower() {
  // Generate Random Lower Case Character
  return String.fromCharCode(Math.floor(Math.random() * 26) + 97);
}
function getRandomUpper() {
  // Generate Random Upper Case Character
  return String.fromCharCode(Math.floor(Math.random() * 26) + 65);
}
function getRandomNumber() {
  // Generate Random Number
  return +String.fromCharCode(Math.floor(Math.random() * 10) + 48);
}
function getRandomSymbol() {
  // Generate Random Symbol
  const symbols = "!@#$%^&*(){}[]=<>/,.";
  return symbols[Math.floor(Math.random() * symbols.length)];
}
const randomFunc = {
  lower: getRandomLower,
  upper: getRandomUpper,
  number: getRandomNumber,
  symbol: getRandomSymbol,
};
function generatePassword() {
  let generatedPassword = "";
  const funcName = Object.keys(randomFunc);
  // To Generat Random Password with 16 Character
  for (var i = 0; i < 4; i++) {
    // To Loop Through All Function
    for (var x = 0; x < 4; x++) {
      generatedPassword += randomFunc[funcName[x]]();
    }
  }
  return generatedPassword;
}
export default generatePassword;
