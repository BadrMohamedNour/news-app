import React, { useEffect, useState, useRef } from "react";
import { Link, Redirect } from "react-router-dom";
import validate from "../Utility/Validate";
import classes from "../Form.css";
import generatePassword from "../Utility/passwordGenerator";
import emailjs from "emailjs-com";
import axios from "axios";
const signup = () => {
  const [state, setState] = useState({
    username: "",
    email: "",
    birthday: "",
  });
  const formRf = useRef();
  const [errors, setError] = useState({});
  const [isValid, setIsValid] = useState(false);
  const [password, setPassword] = useState(generatePassword());
  const [redir, setRedir] = useState(false);
  const submitHandler = (e) => {
    // To prevent The Page From Reloading
    e.preventDefault();
    // Error Will Be The Result Of Excuting Validate Function
    setError(validate(state));
    // To Make useEffect Condition False For The First Time
    setIsValid(true);
    // Password Will Be The Result Of Excuting GenratePassword Function
    setPassword(generatePassword());
  };
  const changeHandler = (e) => {
    // Change State Based on User Inputs
    setState({ ...state, [e.target.name]: e.target.value });
  };
  useEffect(() => {
    // To check If There Is Error && User Doesn't Click Submit Button Directly && Password Was Generated
    if (Object.keys(errors).length === 0 && isValid && password) {
      const data = {
        email: state.email,
        password: password,
        returnSecureToken: true,
      };
      axios
        .post(
          "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyAxZZQxHAlEkprGQxUgG1UoYkK1T2cKJB0",
          data
        )
        .then(() => {
          emailjs
            .sendForm(
              "service_sas7nbl",
              "template_gqym7kv",
              formRf.current,
              "user_qxBGfPNGRmAYKbPfiwWCk"
            )
            .then((res) => {
              console.log(res);
              setRedir(true);
            });
        });
    }
    // Reset State After Signup
    setIsValid(false);
  }, [errors]);
  // To Redirect User After signUp
  let authRedirect = null;
  if (redir) {
    authRedirect = <Redirect to="/login" />;
  }
  // Form Structure
  let form = (
    <form
      ref={formRf}
      method="post"
      onSubmit={submitHandler}
      className={classes.Form}
    >
      <h1>News App</h1>
      <h3>
        Get started with us today! create your account by filling out the
        information below.
      </h3>
      <div>
        <label htmlFor="username">
          <input
            type="text"
            name="username"
            placeholder="User Name"
            value={state.username}
            onChange={changeHandler}
          />
        </label>
        {errors.username && (
          <p className={classes.errormsg}>{errors.username}</p>
        )}
      </div>
      <div>
        <label htmlFor="email">
          <input
            type="email"
            name="email"
            placeholder="Email"
            value={state.email}
            onChange={changeHandler}
          />
        </label>
        {errors.email && <p className={classes.errormsg}>{errors.email}</p>}
      </div>
      <div>
        <input
          type="date"
          name="birthday"
          value={state.birthday}
          onChange={changeHandler}
        />
        {errors.date && <p className={classes.errormsg}>{errors.date}</p>}
      </div>
      <input type="hidden" name="password" value={password} />
      <button type="submit">Sign Up</button>
      <span className={classes.Login}>
        Already have an account? Login <Link to="login">here</Link>
      </span>
    </form>
  );
  return (
    <div className={classes.Content}>
      {authRedirect}
      {form}
    </div>
  );
};

export default signup;
